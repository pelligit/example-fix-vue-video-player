import example01 from './01-video.vue'
import example02 from './02-video.vue'
import example03 from './03-video.vue'
import example04 from './04-video.vue'
import example05 from './05-video.vue'

export default {
  example01,
  example02,
  example03,
  example04,
  example05
}
