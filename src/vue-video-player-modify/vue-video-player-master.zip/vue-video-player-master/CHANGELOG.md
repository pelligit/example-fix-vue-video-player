
## CHANGELOG

### v5.0.2

fix #142 custom event

### v5.0.1

support dynamic change options

### v5.0.0

#### use
1. add global default options
2. update the options assign logic
3. Update to [video.js6](https://github.com/videojs/video.js)

#### project
- add brower support
- add test scripts
- update babel and webpack configs
